#ifndef HEADERS_H
#define HEADERS_H

#include <iostream>
#include <stdlib.h>
#include <iomanip>
#include <vector>
#include <map>
#include <algorithm>
#include <utility>
#include <string.h>
#include <ctype.h>
#include <unistd.h>

using namespace std;
#endif
